package modelo;

//derivada - filha (contem as caracteristicas da classe pai)
public class ContaCorrenteSalario extends ContaCorrente {

	// ============================atributos
	private float limiteMovimentacao;
	// ============================métodos
	// construtores
	public ContaCorrenteSalario() {
		super();
	}
	public ContaCorrenteSalario(float limiteMovimentacao) {
		super();
		this.limiteMovimentacao = limiteMovimentacao;
	}

	public ContaCorrenteSalario(String agencia, String nConta, float saldo, float limiteMovimentacao) {
		super(agencia, nConta, saldo);
		this.limiteMovimentacao = limiteMovimentacao;
	}
	
	//funcionais
	public void alterarLimiteMovimentacao(float valor) {
		this.limiteMovimentacao = valor;
	}
	
	public float getLimiteMovimentacao()
	{
		return limiteMovimentacao;
	}
	

}

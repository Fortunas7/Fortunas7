package modelo;

//base - superclasse - pai
public class Conta{
	//============================atributos
	protected int codigo;
	private String agencia;
	private String nConta;
	protected float saldo;
	
	//============================métodos
	//construtores
	public Conta() {}

	public Conta(String nConta) {
		super();
		this.nConta = nConta;
	}

	public Conta(String agencia, String nConta, float saldo) {
		super();
		this.agencia = agencia;
		this.nConta = nConta;
		this.saldo = saldo;
	}
	//funcionais
	public void sacar(float valor)
	{
		this.saldo = this.saldo - valor;
	}
	public void depositar(float valor)
	{
		this.saldo = this.saldo + valor;
	}
	//acesso - get/set
	public String getAgencia() {
		return agencia;
	}

	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	public String getnConta() {
		return nConta;
	}

	public void setnConta(String nConta) {
		this.nConta = nConta;
	}

	public float getSaldo() {
		return saldo;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}	
	
	

}

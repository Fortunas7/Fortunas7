package modelo;

//derivada - filha (contem as caracteristicas da classe pai)
public class ContaCorrente extends Conta {
	// ============================atributos
	private float limite;
	// ============================métodos
	// construtores
	public ContaCorrente() {
		super();
	}

	public ContaCorrente(float limite) {
		super();
		this.limite = limite;
	}
	
	public ContaCorrente(String agencia, String nConta, float saldo) {
		super(agencia, nConta, saldo);
	}
	

	public ContaCorrente(String agencia, String nConta, float saldo, float limite) {
		super(agencia, nConta, saldo);
		this.limite = limite;
	}

	// funcionais
	public void aumentarLimite(float valor) {
		this.limite = valor;

	}
	public void diminuirLimite(float valor) {
		this.limite = valor;

	}
	// acesso
	public float getLimite() {
		return limite;
	}

}

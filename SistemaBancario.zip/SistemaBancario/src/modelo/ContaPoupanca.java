package modelo;
//derivada - filha (contem as caracteristicas da classe pai)
public class ContaPoupanca extends Conta {

	// ============================atributos
	private float taxaRendimento;
	// ============================métodos
	// construtores
	public ContaPoupanca() {
		super();
	}

	public ContaPoupanca(float taxaRendimento) {
		super();
		this.taxaRendimento = taxaRendimento;
	}
	
	public ContaPoupanca(String agencia, String nConta, float saldo) {
		super(agencia, nConta, saldo);
	}
	
	public ContaPoupanca(String agencia, String nConta, float saldo, float taxaRendimento) {
		super(agencia, nConta, saldo);
		this.taxaRendimento = taxaRendimento;
	}
	// funcionais
	public void aplicarRendimento() {
		this.saldo = this.saldo+(this.saldo*taxaRendimento);
	}
	// acesso
	public float getTaxaRendimento()
	{
		return taxaRendimento;
	}

}

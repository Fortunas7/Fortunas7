package control;

import modelo.Conta;

public class ControleContaVetor {

	public Conta contas[];
	public int numContas;
	public static int codigoConta;

	public ControleContaVetor(int numContas) {
		this.numContas = numContas;
		contas = new Conta[numContas];
		codigoConta = -1;
	}
	//READ
	public Conta buscar(int codigo) {
		for (int i = 0; i < contas.length; i++) {
			if(contas[i].getCodigo()==codigo)
				return contas[i];					
		}		
		return null;
	}
	
	//CREATE
	public boolean criar(Conta c) {
		Conta conta=null;		
		conta = buscar(c.getCodigo());		
		if(conta==null) {
			codigoConta++;
			contas[codigoConta] = c;
			return true;
		}else {
			return false;
		}

	}

	//UPDATE
	public void atualizar() {

	}
	//DELETE
	public void remover() {

	}

}
